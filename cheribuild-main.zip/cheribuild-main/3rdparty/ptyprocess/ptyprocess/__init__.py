"""Run a subprocess in a pseudo terminal"""
from .ptyprocess import PtyProcess, PtyProcessUnicode, PtyProcessError

__version__ = '0.6.0'
