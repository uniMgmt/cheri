Ptyprocess API
==============

.. module:: ptyprocess

.. autoclass:: PtyProcess

   .. automethod:: spawn

.. autoclass:: PtyProcessUnicode
